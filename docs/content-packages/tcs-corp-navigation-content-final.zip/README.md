# TCS Corp sample navigation content

Content package: `tcs-corp-navigation-content-final.zip` (FileVault), 103 pages below
`/content/tcs-corp/us/en/home` (published at `/en/home`): 6 L1, 20 L2 and 77 L3.

Source: Figma New Screens from New DS (yElx5Tf9wr8G2vCXopi49W), page Navigation 1124:25825, desktop Full menu 1124:26209 (labels and order as shown; two-column panels read column by column). The hierarchy is in `navigation-tree.json` and `navigation-tree.csv`.

## Before installing

1. Install on a non-production author first.
2. Check the page defaults against an existing page of the site (CRXDE, e.g.
   `/content/tcs-corp/us/en/home/jcr:content`): every page uses `cq:template="/libs/core/franklin/templates/page"` and
   `sling:resourceType="core/franklin/components/page/v1/page"` (the aem-boilerplate-xwalk defaults; they could not be read
   from the target author). If they differ, change them in the package or rebuild it.
3. The filter has one root per L1 page in `merge` mode: pages that already exist are left as they
   are (properties and children), nothing is deleted, the Home page itself isn't touched.

## What each page has

- `jcr:title` and `nav-title` (Navigation Title): the Figma label.
- `nav-order` (Navigation Order): its position among its siblings in Figma (1 first).
- `hide-in-nav` (Hide in navigation): false.
- A section with a title (h1) and one paragraph marked as placeholder content; no images.

## After installing

1. Publish the pages (Manage Publication, or Quick Publish of the tree). The navigation reads the
   published pages (query index), so unpublished pages don't appear.
2. On the Navigation page (e.g. `/content/tcs-corp/us/en/references/tcs-header`):
   - Conversation Canvas: Menu root path `/content/tcs-corp/us/en/home`, Menu depth 3.
   - TCS Header: Navigation root `/content/tcs-corp/us/en/home`, Navigation depth 3 (tablet and mobile menu).
3. Re-publish the Navigation page.

## Placeholders to confirm

- Insights has no sub-pages: Figma shows only "Dynamic category" placeholders.
- Careers L3 items show an external-link arrow in Figma; no URLs were given, so they are pages here.
- Investors > Financials > Download TCS Data Sheet reads like a download link, not a page.
- Figma's labels are kept as they are (e.g. "Capital markets", "Consumer goods", "Energy & utility").
